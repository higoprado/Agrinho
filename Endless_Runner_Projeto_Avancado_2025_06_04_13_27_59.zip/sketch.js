// O Prompt - (mantido para referência)
/*
  Endless Runner: Festejando Conexão do Campo e da Cidade

  Funcionalidades:
  - Fundo dividido: Ambiente rural (à esquerda) e urbano (à direita) com nuvens em movimento.
  - Iluminação dinâmica: A cada 1000 pontos o ciclo alterna entre dia (sol) e noite (lua) e o brilho dos elementos é ajustado.
  - Power‑ups: Existem 4 tipos – invincibility, slowMotion, doubleJump e doubleScore.
  - Linha de chegada: Ao atingir 10.000 pontos o jogo mostra uma linha de chegada e, ao ser cruzada, o desafio é completado.
  - Tela de menu com instruções das regras, objetivo e atalhos:
      • M para começar/reiniciar;
      • E para pausar/resumir.
  - Botão de Pause/Resume (no canto superior direito) e atalho com a tecla E.
  - Personagem principal: Agora é um personagem de palito com animações de corrida (braços e pernas oscilantes) e um pose de salto.

  Controles:
    - Setas para esquerda/direita: movimentação.
    - Seta para cima: pular.
    - Tecla E: pausar/resumir.
    - Tecla M: iniciar/reiniciar o jogo.
*/

// ===============================================
// CONSTANTES GLOBAIS
// ===============================================
const GRAVITY = 0.6;
const JUMP_FORCE = -12;
const BASE_SCROLL_SPEED = 6;
const OBSTACLE_INITIAL_INTERVAL = 120; // Mais espaçado para facilitar
const POWER_UP_INITIAL_INTERVAL = 600;

// Duração dos power-ups em frames (60 frames/segundo)
const INVINCIBILITY_DURATION = 5 * 60;
const SLOW_MOTION_DURATION = 5 * 60;
const DOUBLE_JUMP_DURATION = 5 * 60;
const DOUBLE_SCORE_DURATION = 5 * 60;

const FINISH_SCORE = 10000;
const DAY_NIGHT_CYCLE_SCORE = 1000;

// ===============================================
// VARIÁVEIS DO JOGO
// ===============================================
let gameState = "menu"; // Estados: "menu", "playing", "paused", "gameOver", "finished"

let player;
let groundY;
let obstacles = [];
let obstacleTimer = 0;
let scrollSpeed = BASE_SCROLL_SPEED;
let score = 0;
let jumpKeyActive = false; // Controla se a tecla de pulo está segurada

let powerUps = [];
let powerUpTimer = 0;

let particles = [];
let clouds = [];

// Elementos de fundo para Parallax
let ruralBackgroundElements = [];
let urbanBackgroundElements = [];

// Variáveis para efeitos visuais
let collectEffects = []; // Para efeitos de coleta de power-ups
let screenFlash = {
  active: false,
  color: null,
  duration: 0,
  timer: 0
};

let controlButtons = {}; // Objeto para armazenar as posições dos botões de controle na tela

// Variáveis para a linha de chegada e vitória
let levelComplete = false;
let finishLineX;
let finished = false;

// Variável global para armazenar o retângulo do botão de pause/resume.
let pauseButtonRect = null;

// Variáveis para sons (descomente e carregue os arquivos se for usar)
// let backgroundMusic;
// let jumpSound;
// let powerUpSound;
// let gameOverSound;

// ===============================================
// CLASSES DO JOGO
// ===============================================

// Classe para o Jogador (Stick Figure)
class Player {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.vy = 0; // Velocidade vertical
    this.speed = 5; // Velocidade horizontal

    // Power-ups
    this.invincible = false;
    this.invincibleTimer = 0;
    this.slowMotion = false;
    this.slowMotionTimer = 0;
    this.doubleJump = false;
    this.doubleJumpTimer = 0;
    this.doubleScore = false;
    this.doubleScoreTimer = 0;

    this.jumpsRemaining = 1; // Para double jump

    // Squash & Stretch
    this.squashStretchFactor = 1; // 1 = normal, <1 = squash, >1 = stretch
    this.squashStretchSpeed = 0.1; // Velocidade da animação
    this.targetSquashStretch = 1; // Valor alvo
  }

  update() {
    // Aplicar gravidade
    this.vy += GRAVITY;
    this.y += this.vy;

    // Animação de Squash & Stretch
    this.squashStretchFactor = lerp(this.squashStretchFactor, this.targetSquashStretch, this.squashStretchSpeed);

    // Colisão com o chão
    if (this.y > groundY - this.size / 2 * this.squashStretchFactor) { // Ajuste para o fator de squash/stretch
      this.y = groundY - this.size / 2 * this.squashStretchFactor; // Ajuste para o fator de squash/stretch
      this.vy = 0;
      this.jumpsRemaining = this.doubleJump ? 2 : 1; // Reseta pulos ao tocar o chão
      this.targetSquashStretch = 1; // Volta ao normal ao tocar o chão
    }

    // Atualizar timers dos power-ups
    this.updatePowerUpTimers();
  }

  draw() {
    push();
    // Ajusta a translação para que o centro da base do jogador permaneça no chão
    // Quando squashed, o personagem se "achata" para baixo, então movemos o Y para cima.
    // Quando stretched, o personagem "estica" para cima, então movemos o Y para baixo.
    translate(this.x, this.y + (1 - this.squashStretchFactor) * this.size * 0.5);
    scale(1, this.squashStretchFactor); // Aplica escala no eixo Y para squash/stretch

    stroke(0);
    strokeWeight(2);

    // Cabeça
    fill(0);
    ellipse(0, -this.size * 0.75, this.size * 0.5, this.size * 0.5);

    // Corpo
    line(0, -this.size * 0.5 + this.size * 0.1, 0, this.size * 0.2);

    // Animação de corrida ou salto
    if (this.y < groundY - this.size / 2 - 1) { // No ar
      // Pose de salto: braços levantados e pernas estendidas.
      line(0, -this.size * 0.5 + this.size * 0.1, this.size * 0.3, -this.size * 0.6);
      line(0, -this.size * 0.5 + this.size * 0.1, -this.size * 0.3, -this.size * 0.6);
      line(0, this.size * 0.2, this.size * 0.2, this.size * 0.6);
      line(0, this.size * 0.2, -this.size * 0.2, this.size * 0.6);
    } else { // No chão
      // Pose de corrida: animação dos braços e pernas com base no frameCount.
      let swing = sin(frameCount * 0.3) * this.size * 0.15;
      line(0, -this.size * 0.5 + this.size * 0.1, this.size * 0.3 + swing, -this.size * 0.5 + swing);
      line(0, -this.size * 0.5 + this.size * 0.1, -this.size * 0.3 - swing, -this.size * 0.5 + swing);
      line(0, this.size * 0.2, player.size * 0.2 - swing, player.size * 0.6);
      line(0, player.size * 0.2, -player.size * 0.2 + swing, player.size * 0.6);
    }

    // Feedback visual para invencibilidade
    if (this.invincible) {
      noFill();
      stroke(0, 255, 255, 150 + 100 * sin(frameCount * 0.2)); // Brilho pulsante
      strokeWeight(4);
      ellipse(0, -this.size * 0.2, this.size * 1.5, this.size * 1.5);
    }

    pop();
  }

  jump() {
    if (this.jumpsRemaining > 0) {
      this.targetSquashStretch = 0.7; // Achata antes de pular (squash)
      this.vy = this.doubleJump ? JUMP_FORCE * 1.5 : JUMP_FORCE; // Pulo mais alto com doubleJump
      this.jumpsRemaining--;
      // if (jumpSound) jumpSound.play();
      spawnDust(this.x, this.y + this.size / 2);
    }
  }

  updatePowerUpTimers() {
    if (this.invincible) {
      this.invincibleTimer--;
      if (this.invincibleTimer <= 0) {
        this.invincible = false;
        this.invincibleTimer = 0;
      }
    }
    if (this.slowMotion) {
      this.slowMotionTimer--;
      if (this.slowMotionTimer <= 0) {
        this.slowMotion = false;
        this.slowMotionTimer = 0;
      }
    }
    if (this.doubleJump) {
      this.doubleJumpTimer--;
      if (this.doubleJumpTimer <= 0) {
        this.doubleJump = false;
        this.doubleJumpTimer = 0;
        this.jumpsRemaining = 1; // Reseta para pulo único ao fim do doubleJump
      }
    }
    if (this.doubleScore) {
      this.doubleScoreTimer--;
      if (this.doubleScoreTimer <= 0) {
        this.doubleScore = false;
        this.doubleScoreTimer = 0;
      }
    }
  }

  getBounds() {
    // Ajusta os limites para o squash/stretch
    return {
      x: this.x - this.size / 2,
      y: this.y - this.size / 2 * this.squashStretchFactor,
      w: this.size,
      h: this.size * this.squashStretchFactor,
    };
  }
}

// Classe para Obstáculos
class Obstacle {
  constructor(x, y, w, h, type) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.type = type; // "tree" ou "building"
  }

  update() {
    this.x -= scrollSpeed;
  }

  draw() {
    push();
    translate(this.x, this.y);
    noStroke();

    if (this.type === "tree") {
      fill(101, 67, 33); // Tronco
      let trunkWidth = this.w * 0.5;
      let trunkHeight = this.h * 0.4;
      rect(this.w / 2 - trunkWidth / 2, this.h - trunkHeight, trunkWidth, trunkHeight);
      fill(34, 139, 34); // Folhagem
      triangle(this.w / 2 - this.w, this.h - trunkHeight, this.w / 2 + this.w, this.h - trunkHeight, this.w / 2, 0);
      ellipse(this.w / 2, this.h - trunkHeight - this.h * 0.1, this.w * 1.5, this.h * 0.8);
    } else if (this.type === "building") {
      fill(120); // Prédio
      rect(0, 0, this.w, this.h);
      fill(255, 255, 0); // Janelas (amarelas)
      let numWindowsX = floor(this.w / 15);
      let numWindowsY = floor(this.h / 20);
      for (let i = 0; i < numWindowsX; i++) {
        for (let j = 0; j < numWindowsY; j++) {
          let winX = i * 15 + 3;
          let winY = j * 20 + 3;
          if (winX + 10 < this.w && winY + 10 < this.h) { // Evita desenhar janelas fora do prédio
            rect(winX, winY, 10, 10);
          }
        }
      }
    }
    pop();
  }

  isOffscreen() {
    return this.x + this.w < 0;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      w: this.w,
      h: this.h
    };
  }
}

// Classe para Power-ups
class PowerUp {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.w = 25;
    this.h = 25;
    this.type = type; // "invincibility", "slowMotion", "doubleJump", "doubleScore"
  }

  update() {
    this.x -= scrollSpeed;
  }

  draw() {
    push();
    translate(this.x, this.y);
    let scaleFactor = 1 + 0.1 * sin(frameCount * 0.1);
    scale(scaleFactor);
    noStroke();

    if (this.type === "invincibility") {
      fill(0, 255, 255, 200); // Ciano
    } else if (this.type === "slowMotion") {
      fill(128, 0, 128, 200); // Roxo
    } else if (this.type === "doubleJump") {
      fill(0, 200, 0, 200); // Verde
    } else if (this.type === "doubleScore") {
      fill(0, 0, 255, 200); // Azul
    }
    ellipse(0, 0, this.w, this.h);

    // Adicionar ícone ou letra para identificar o power-up
    fill(255);
    textSize(16);
    textAlign(CENTER, CENTER);
    if (this.type === "invincibility") text("I", 0, 0);
    else if (this.type === "slowMotion") text("S", 0, 0);
    else if (this.type === "doubleJump") text("J", 0, 0);
    else if (this.type === "doubleScore") text("D", 0, 0);

    pop();
  }

  isOffscreen() {
    return this.x + this.w < 0;
  }

  getBounds() {
    return {
      x: this.x - this.w / 2,
      y: this.y - this.h / 2,
      w: this.w,
      h: this.h
    };
  }
}

// Classe para Partículas
class Particle {
  constructor(x, y, vx, vy, lifetime, color) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.lifetime = lifetime;
    this.initialLifetime = lifetime;
    this.color = color;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.lifetime--;
    this.vy += GRAVITY * 0.1; // Partículas de poeira caem levemente
  }

  draw() {
    noStroke();
    let alpha = map(this.lifetime, 0, this.initialLifetime, 0, 255);
    fill(red(this.color), green(this.color), blue(this.color), alpha);
    ellipse(this.x, this.y, 5);
  }

  isDead() {
    return this.lifetime <= 0;
  }
}

// Classe para efeitos de coleta (anel que se expande)
class CollectEffect {
  constructor(x, y, initialRadius, maxRadius, duration, effectColor) {
    this.x = x;
    this.y = y;
    this.radius = initialRadius;
    this.maxRadius = maxRadius;
    this.duration = duration;
    this.timer = duration;
    this.effectColor = effectColor;
  }

  update() {
    this.radius = map(this.timer, this.duration, 0, this.initialRadius, this.maxRadius);
    this.timer--;
  }

  draw() {
    if (this.timer > 0) {
      let alpha = map(this.timer, 0, this.duration, 0, 200); // Fading out
      stroke(red(this.effectColor), green(this.effectColor), blue(this.effectColor), alpha);
      strokeWeight(4);
      noFill();
      ellipse(this.x, this.y, this.radius * 2, this.radius * 2);
    }
  }

  isDead() {
    return this.timer <= 0;
  }
}

// Classe para elementos de fundo rural (árvores, moitas, etc.)
class RuralBackgroundElement {
  constructor(x, y, w, h, speedMultiplier) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.speedMultiplier = speedMultiplier; // Multiplicador da velocidade de rolagem
  }

  update() {
    this.x -= scrollSpeed * this.speedMultiplier;
    // Reinicia a posição se sair da tela (para criar o efeito "infinito")
    if (this.x + this.w < 0) {
      this.x = width + random(50, 200); // Aparece em um local aleatório no final
      this.y = random(groundY - 50, groundY - 20); // Altura variável
    }
  }

  draw(lightingFactor) {
    push();
    translate(this.x, this.y);
    noStroke();

    // Tronco
    fill(101 * lightingFactor, 67 * lightingFactor, 33 * lightingFactor, 200);
    rect(0, 0, this.w * 0.3, this.h);
    // Folhagem
    fill(34 * lightingFactor, 139 * lightingFactor, 34 * lightingFactor, 200);
    ellipse(this.w * 0.15, -this.h * 0.3, this.w * 1.5, this.h * 0.8);
    pop();
  }
}

// Classe para elementos de fundo urbano (prédios)
class UrbanBackgroundElement {
  constructor(x, y, w, h, speedMultiplier) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.speedMultiplier = speedMultiplier; // Multiplicador da velocidade de rolagem
    this.windowsState = []; // Matriz para armazenar o estado de cada janela (true/false)
    this.numWindowsX = floor(this.w / 15);
    this.numWindowsY = floor(this.h / 20);
    this.lastWindowChangeFrame = 0; // Para controlar a frequência de piscar

    // Inicializa o estado das janelas
    this.initializeWindowsState();
  }

  // Novo método para inicializar/reinicializar o estado das janelas
  initializeWindowsState() {
    this.windowsState = [];
    for (let i = 0; i < this.numWindowsX; i++) {
      this.windowsState[i] = [];
      for (let j = 0; j < this.numWindowsY; j++) {
        this.windowsState[i][j] = random(1) > 0.5; // Mais janelas acesas inicialmente
      }
    }
  }

  update() {
    this.x -= scrollSpeed * this.speedMultiplier;
    // Reinicia a posição se sair da tela
    if (this.x + this.w < 0) {
      this.x = width + random(50, 200); // Aparece em um local aleatório no final
      this.w = random(20, 50);
      this.h = random(groundY * 0.2, groundY * 0.5);
      this.y = groundY - this.h;

      // Reinicializa o estado das janelas para o novo prédio
      this.numWindowsX = floor(this.w / 15);
      this.numWindowsY = floor(this.h / 20);
      this.initializeWindowsState();
    }
  }

  draw(lightingFactor) {
    push();
    translate(this.x, this.y);
    noStroke();
    fill(30 * lightingFactor, 30 * lightingFactor, 30 * lightingFactor, 230);
    rect(0, 0, this.w, this.h);

    // Determina a frequência de mudança das janelas com base no estado do jogo
    let changeProbability = 0; // Nenhuma mudança por padrão
    let changeInterval = 0; // Nunca muda

    if (gameState === "playing") {
      changeProbability = 0.05; // 5% de chance de mudar a cada frame (pisca mais)
      changeInterval = 5; // A cada 5 frames, tenta mudar
    } else if (gameState === "paused" || gameState === "gameOver" || gameState === "finished") {
      changeProbability = 0.005; // 0.5% de chance de mudar (pisca muito menos, quase imperceptível)
      changeInterval = 30; // A cada 30 frames, tenta mudar
    }

    // Atualiza o estado das janelas se o intervalo e a probabilidade permitirem
    if (frameCount % changeInterval === 0) {
      for (let i = 0; i < this.numWindowsX; i++) {
        for (let j = 0; j < this.numWindowsY; j++) {
          if (random(1) < changeProbability) {
            this.windowsState[i][j] = !this.windowsState[i][j]; // Inverte o estado da janela
          }
        }
      }
    }

    // Desenha as janelas
    fill(255 * lightingFactor, 255 * lightingFactor, 100 * lightingFactor, 80);
    for (let i = 0; i < this.numWindowsX; i++) {
      for (let j = 0; j < this.numWindowsY; j++) {
        let winX = i * 15 + 3;
        let winY = j * 20 + 3;
        // Desenha a janela apenas se ela estiver "ligada" (true no windowsState)
        if (this.windowsState[i][j] && winX + 10 < this.w && winY + 10 < this.h) {
          rect(winX, winY, 10, 10);
        }
      }
    }
    pop();
  }
}

// ===============================================
// FUNÇÕES GERAIS DO P5.JS
// ===============================================

function preload() {
  // Caso deseje incluir sons, descomente e carregue os respectivos arquivos:
  // backgroundMusic = loadSound('assets/background.mp3');
  // jumpSound = loadSound('assets/jump.wav');
  // powerUpSound = loadSound('assets/powerup.wav');
  // gameOverSound = loadSound('assets/gameover.wav');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(2); // Para melhor renderização em telas de alta densidade
  groundY = height * 0.75;

  initializeGameElements();

  frameRate(60);

  // Se utilizar som, inicie a música de fundo:
  // if (backgroundMusic) backgroundMusic.loop();
}

function draw() {
  drawBackdrop(); // Desenha o fundo (sempre ativo para ambiente)

  // Exibe o botão de pause/resume se o jogo estiver ativo ou pausado
  if (gameState === "playing" || gameState === "paused") {
    drawPauseButton();
  }

  if (gameState === "menu") {
    drawMenu();
    // Nenhuma atualização de jogo no menu
  } else if (gameState === "playing") {
    // TODA A LÓGICA DE ATUALIZAÇÃO E MOVIMENTO ACONTECE AQUI
    updateGame(); // <--- CHAMA updateGame() APENAS NO ESTADO "playing"
    drawGame(); // Desenha o estado atual do jogo (elementos em movimento)
    updateParticles(); // Partículas continuam ativas
    for (let i = collectEffects.length - 1; i >= 0; i--) { // Atualiza efeitos de coleta
      collectEffects[i].update();
      if (collectEffects[i].isDead()) {
        collectEffects.splice(i, 1);
      }
    }
    drawParticles();
    for (let effect of collectEffects) { // Desenha efeitos de coleta
      effect.draw();
    }
    drawControls(); // Controles na tela para mobile
    displayScore();
    displayPowerUpTimers(); // Exibe timers dos power-ups
    drawScreenFlash(); // Flash ocorre ao colidir e no estado "playing"
  } else if (gameState === "paused") {
    // Quando pausado, NÃO chame updateGame().
    drawGame(); // Desenha o estado atual do jogo (parado)
    // Partículas e efeitos de coleta devem continuar, mas de forma mínima ou parar gradualmente
    updateParticles();
    for (let i = collectEffects.length - 1; i >= 0; i--) {
        collectEffects[i].update();
        if (collectEffects[i].isDead()) {
            collectEffects.splice(i, 1);
        }
    }
    drawParticles();
    for (let effect of collectEffects) {
        effect.draw();
    }
    drawControls();
    displayScore();
    displayPowerUpTimers();
    // Overlay de pausa
    fill(0, 0, 0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("PAUSED", width / 2, height / 2);
  } else if (gameState === "gameOver") {
    // Quando em "gameOver", NÃO chame updateGame() para parar a lógica principal do jogo.
    // Apenas desenhe os elementos existentes para a "cena final".
    drawGame(); // Desenha o último estado dos elementos do jogo
    updateParticles(); // Partículas continuam para efeito visual
    for (let i = collectEffects.length - 1; i >= 0; i--) {
      collectEffects[i].update();
      if (collectEffects[i].isDead()) {
        collectEffects.splice(i, 1);
      }
    }
    drawParticles();
    for (let effect of collectEffects) {
      effect.draw();
    }
    drawControls(); // Controles ainda podem ser desenhados, mas não interagem
    displayGameOver(); // Exibe a tela de Game Over
    displayScore();
    drawScreenFlash(); // Flash de tela ainda aparece brevemente na colisão
  } else if (gameState === "finished") {
    // Quando em "finished", semelhante a "gameOver", parar a lógica principal.
    drawGame(); // Desenha o último estado do jogo, incluindo a linha de chegada
    updateParticles(); // Partículas continuam para efeito visual
    for (let i = collectEffects.length - 1; i >= 0; i--) {
      collectEffects[i].update();
      if (collectEffects[i].isDead()) {
        collectEffects.splice(i, 1);
      }
    }
    drawParticles();
    for (let effect of collectEffects) {
      effect.draw();
    }
    drawControls();
    displayFinish(); // Exibe a tela de vitória
    displayScore();
  }
}

// ===============================================
// FUNÇÕES DE JOGO PRINCIPAIS
// ===============================================

function initializeGameElements() {
  player = new Player(100, groundY - 20, 40);

  obstacles = [];
  obstacleTimer = 0;
  scrollSpeed = BASE_SCROLL_SPEED;
  score = 0;
  jumpKeyActive = false; // Garante que não está pulando ao resetar

  powerUps = [];
  powerUpTimer = 0;

  particles = [];
  collectEffects = []; // Reinicia os efeitos de coleta também

  // Recria nuvens (para garantir que sejam geradas corretamente em reset)
  clouds = [];
  for (let i = 0; i < 5; i++) {
    let cloud = {
      x: random(0, width),
      y: random(50, height * 0.3),
      size: random(50, 150),
      speed: random(0.5, 1.5)
    };
    clouds.push(cloud);
  }

  // Gera elementos de fundo para parallax scrolling
  ruralBackgroundElements = [];
  // Gera mais árvores para preencher o lado rural e se moverem continuamente
  for (let i = 0; i < 10; i++) {
    ruralBackgroundElements.push(new RuralBackgroundElement(random(0, width / 2), random(groundY - 50, groundY - 20), random(20, 40), random(30, 60), 0.3)); // speedMultiplier 0.3
  }

  urbanBackgroundElements = [];
  // Gera mais prédios para preencher o lado urbano e se moverem continuamente
  for (let i = 0; i < 10; i++) {
    let bWidth = random(30, 60);
    let bHeight = random(groundY * 0.2, groundY * 0.5);
    urbanBackgroundElements.push(new UrbanBackgroundElement(random(width / 2, width), groundY - bHeight, bWidth, bHeight, 0.4)); // speedMultiplier 0.4
  }

  levelComplete = false;
  finished = false;
  finishLineX = undefined;
}


function updateGame() {
  // ATENÇÃO: Toda a lógica de movimento e atualização deve estar AQUI dentro!

  // Atualiza score
  score += player.doubleScore ? 2 : 1;

  // Ajusta velocidade de rolagem
  let baseSpeed = BASE_SCROLL_SPEED + floor(score / 500);
  scrollSpeed = player.slowMotion ? baseSpeed * 0.7 : baseSpeed;

  // Checa linha de chegada
  if (!levelComplete && score >= FINISH_SCORE) {
    levelComplete = true;
    finishLineX = width; // A linha de chegada aparece na direita
  }

  // Controles do jogador (setas e controles na tela)
  let ctrl = getControlInput();
  if ((ctrl.up || keyIsDown(UP_ARROW)) && !jumpKeyActive) {
    player.jump();
    jumpKeyActive = true; // Impede pulos múltiplos enquanto a tecla estiver pressionada
  }
  if (!ctrl.up && !keyIsDown(UP_ARROW)) {
    jumpKeyActive = false; // Reseta o estado da tecla quando solta
  }

  if (keyIsDown(LEFT_ARROW) || ctrl.left) player.x -= player.speed;
  if (keyIsDown(RIGHT_ARROW) || ctrl.right) player.x += player.speed;
  player.x = constrain(player.x, 0, width); // Mantém o jogador na tela

  player.update(); // Atualiza a lógica do jogador (gravidade, power-ups)


  // --- ATUALIZAÇÕES DO BACKGROUND E NUVENS ---

  // Elementos de fundo rural (árvores e colinas) com parallax
  for (let t of ruralBackgroundElements) {
    t.update();
  }

  // Elementos de fundo urbano (prédios) com parallax
  for (let b of urbanBackgroundElements) {
    b.update();
  }

  // Nuvens (atualização de movimento)
  for (let cloud of clouds) {
    cloud.x -= cloud.speed;
    if (cloud.x + cloud.size < 0) {
      cloud.x = width + cloud.size;
      cloud.y = random(50, height * 0.3);
      cloud.size = random(50, 150);
      cloud.speed = random(0.5, 1.5);
    }
  }

  // --- FIM DAS ATUALIZAÇÕES DO BACKGROUND ---


  // Geração e atualização de obstáculos
  if (!levelComplete) {
    obstacleTimer++;
    if (obstacleTimer > OBSTACLE_INITIAL_INTERVAL) { // Pode ser ajustado para dificultar
      spawnObstacle();
      obstacleTimer = 0;
    }
    for (let i = obstacles.length - 1; i >= 0; i--) {
      obstacles[i].update();
      if (obstacles[i].isOffscreen()) {
        obstacles.splice(i, 1);
      }
    }

    // Geração e atualização de power-ups
    powerUpTimer++;
    if (powerUpTimer > POWER_UP_INITIAL_INTERVAL) { // Pode ser ajustado para dificultar
      spawnPowerUp();
      powerUpTimer = 0;
    }
    for (let i = powerUps.length - 1; i >= 0; i--) {
      powerUps[i].update();
      if (powerUps[i].isOffscreen()) {
        powerUps.splice(i, 1);
      }
    }

    // Checagem de colisões (obstáculos e power-ups)
    if (!player.invincible) {
      checkCollisions();
    }
    checkPowerUpCollisions();

  } else { // Se o nível está completo, limpa obstáculos e power-ups
    obstacles = [];
    powerUps = [];
    finishLineX -= scrollSpeed; // Move a linha de chegada
    if (finishLineX < player.x) {
      gameState = "finished";
    }
  }
}

function drawGame() {
  drawGround();

  // Desenha a linha de chegada
  if (levelComplete) {
    stroke(255, 215, 0); // Cor dourada
    strokeWeight(8); // Mais espessa
    line(finishLineX, groundY, finishLineX, height);
    noStroke();
  }

  // Desenha obstáculos
  for (let obs of obstacles) {
    obs.draw();
  }

  // Desenha power-ups
  for (let p of powerUps) {
    p.draw();
  }

  player.draw(); // Desenha o jogador
}


// ===============================================
// FUNÇÕES DE DESENHO DO CENA
// ===============================================

function drawBackdrop() {
  let dayCycle = floor(score / DAY_NIGHT_CYCLE_SCORE) % 2;
  let lightingFactor = dayCycle === 0 ? 1.0 : 0.5; // 1.0 para dia, 0.5 para noite

  // Céu: Gradiente vertical
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let skyColor = lerpColor(
      color(120 * lightingFactor, 100 * lightingFactor, 130 * lightingFactor), // Topo (púrpura/azul mais claro)
      color(20 * lightingFactor, 20 * lightingFactor, 50 * lightingFactor), // Base (azul escuro)
      inter
    );
    stroke(skyColor);
    line(0, y, width, y);
  }
  noStroke();

  // Sol ou Lua
  if (dayCycle === 0) { // Dia
    fill(255, 204, 0); // Amarelo do sol
    ellipse(80, 80, 80, 80);
  } else { // Noite
    fill(230); // Branco da lua
    ellipse(80, 80, 60, 60);
    fill(20, 20, 50); // Cor de fundo para criar a "mordida" da lua crescente
    ellipse(90, 70, 60, 60);
  }

  // Elementos de fundo rural (árvores e colinas) com parallax - APENAS DESENHO AQUI
  for (let t of ruralBackgroundElements) {
    t.draw(lightingFactor); // Desenha com o fator de iluminação
  }

  // Elementos de fundo urbano (prédios) com parallax - APENAS DESENHO AQUI
  for (let b of urbanBackgroundElements) {
    b.draw(lightingFactor); // Desenha com o fator de iluminação
  }

  // Nuvens - APENAS DESENHO AQUI
  for (let cloud of clouds) {
    fill(255, 255, 255, 150); // Nuvens brancas sem alteração de iluminação
    ellipse(cloud.x, cloud.y, cloud.size, cloud.size * 0.6);
  }
}


function drawGround() {
  let dayCycle = floor(score / DAY_NIGHT_CYCLE_SCORE) % 2;
  let lightingFactor = dayCycle === 0 ? 1.0 : 0.5;

  for (let x = 0; x < width; x++) {
    let inter = map(x, 0, width, 0, 1);
    let groundColor = lerpColor(
      color(85 * lightingFactor, 170 * lightingFactor, 85 * lightingFactor), // Cor do chão rural
      color(150 * lightingFactor, 150 * lightingFactor, 150 * lightingFactor), // Cor do chão urbano
      inter
    );
    stroke(groundColor);
    line(x, groundY, x, height);
  }
  noStroke();
}


// ===============================================
// SPAWN DE ELEMENTOS
// ===============================================

function spawnObstacle() {
  let obs = {};
  let threshold = FINISH_SCORE / 2; // Começa a gerar prédios mais cedo
  let type;
  let obsW, obsH;

  if (score < threshold) {
    type = "tree";
    obsW = random(20, 30);
    obsH = random(30, 50);
  } else {
    type = "building";
    obsW = random(30, 50);
    obsH = random(40, 80);
  }
  let obsX = width;
  let obsY = groundY - obsH;
  obstacles.push(new Obstacle(obsX, obsY, obsW, obsH, type));
}


function spawnPowerUp() {
  let types = ["invincibility", "slowMotion", "doubleJump", "doubleScore"];
  let randomType = random(types);

  let puX = width;
  let puY = groundY - random(50, 150); // Altura variável
  powerUps.push(new PowerUp(puX, puY, randomType));
}


// ===============================================
// COLISÕES
// ===============================================

function checkCollisions() {
  let playerRect = player.getBounds();
  for (let obs of obstacles) {
    let obsRect = obs.getBounds();
    if (
      playerRect.x < obsRect.x + obsRect.w &&
      playerRect.x + playerRect.w > obsRect.x &&
      playerRect.y < obsRect.y + obsRect.h &&
      playerRect.y + playerRect.h > obsRect.y
    ) {
      // Efeito de impacto:
      spawnCollisionParticles(player.x, player.y); // Nova função para partículas de colisão
      flashScreen(color(255, 0, 0, 150), 10); // Flash vermelho de 10 frames

      gameState = "gameOver";
      // if (gameOverSound) gameOverSound.play();
      break; // Sai do loop assim que uma colisão é detectada
    }
  }
}

function checkPowerUpCollisions() {
  let playerRect = player.getBounds();
  for (let i = powerUps.length - 1; i >= 0; i--) {
    let pu = powerUps[i];
    let puRect = pu.getBounds();
    if (
      playerRect.x < puRect.x + puRect.w &&
      playerRect.x + playerRect.w > puRect.x &&
      playerRect.y < puRect.y + puRect.h &&
      playerRect.y + playerRect.h > puRect.y
    ) {
      // Aplicar power-up ao jogador
      if (pu.type === "invincibility") {
        player.invincible = true;
        player.invincibleTimer = INVINCIBILITY_DURATION;
      } else if (pu.type === "slowMotion") {
        player.slowMotion = true;
        player.slowMotionTimer = SLOW_MOTION_DURATION;
      } else if (pu.type === "doubleJump") {
        player.doubleJump = true;
        player.doubleJumpTimer = DOUBLE_JUMP_DURATION;
        player.jumpsRemaining = 2; // Garante que o jogador pode dar o segundo pulo imediatamente
      } else if (pu.type === "doubleScore") {
        player.doubleScore = true;
        player.doubleScoreTimer = DOUBLE_SCORE_DURATION;
      }
      powerUps.splice(i, 1); // Remove o power-up coletado
      // if (powerUpSound) powerUpSound.play();
      spawnPowerUpParticles(player.x, player.y, color(255, 200, 0)); // Partículas douradas
      // NOVO: Adiciona o efeito de anel
      collectEffects.push(new CollectEffect(player.x, player.y, 10, 60, 30, color(255, 200, 0)));
    }
  }
}


// ===============================================
// PARTICULAS E EFEITOS
// ===============================================

function spawnDust(x, y) {
  for (let i = 0; i < 5; i++) {
    particles.push(new Particle(x, y, random(-1, 1), random(0, -2), random(30, 50), color(150, 150, 150)));
  }
}

function spawnPowerUpParticles(x, y, particleColor) {
  for (let i = 0; i < 20; i++) {
    particles.push(new Particle(x, y, random(-3, 3), random(-3, 3), random(40, 80), particleColor || color(255, 255, 255)));
  }
}

function spawnCollisionParticles(x, y) {
  for (let i = 0; i < 30; i++) { // Mais partículas para um impacto maior
    let angle = random(TWO_PI);
    let speed = random(2, 6);
    let vx = cos(angle) * speed;
    let vy = sin(angle) * speed;
    particles.push(new Particle(x, y, vx, vy, random(40, 80), color(255, 100, 0))); // Partículas laranjas
  }
}


function updateParticles() {
  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].update();
    if (particles[i].isDead()) {
      particles.splice(i, 1);
    }
  }
}

function drawParticles() {
  for (let p of particles) {
    p.draw();
  }
}

function flashScreen(c, duration) {
  screenFlash.active = true;
  screenFlash.color = c;
  screenFlash.duration = duration;
  screenFlash.timer = duration;
}

function drawScreenFlash() {
  if (screenFlash.active && screenFlash.timer > 0) {
    // Calcula o valor alfa que desvanecerá
    let currentAlpha = map(screenFlash.timer, 0, screenFlash.duration, 0, alpha(screenFlash.color));

    // Aplica a cor de preenchimento com o alfa calculado
    fill(red(screenFlash.color), green(screenFlash.color), blue(screenFlash.color), currentAlpha);
    rect(0, 0, width, height);
    screenFlash.timer--;
  } else {
    screenFlash.active = false;
  }
}


// ===============================================
// EXIBIÇÃO DE INFORMAÇÕES E ESTADOS
// ===============================================

function displayScore() {
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Score: " + score, 10, 10);
}

function displayPowerUpTimers() {
  fill(0);
  textSize(18);
  textAlign(LEFT, TOP);
  let yOffset = 40;
  if (player.invincible) {
    let seconds = ceil(player.invincibleTimer / 60);
    text("Invencibilidade: " + seconds + "s", 10, yOffset);
    yOffset += 30;
  }
  if (player.slowMotion) {
    let seconds = ceil(player.slowMotionTimer / 60);
    text("Câmera Lenta: " + seconds + "s", 10, yOffset);
    yOffset += 30;
  }
  if (player.doubleJump) {
    let seconds = ceil(player.doubleJumpTimer / 60);
    text("Salto Duplo: " + seconds + "s", 10, yOffset);
    yOffset += 30;
  }
  if (player.doubleScore) {
    let seconds = ceil(player.doubleScoreTimer / 60);
    text("Pontuação Dupla: " + seconds + "s", 10, yOffset);
  }
}

function drawMenu() {
  background(255, 255, 255, 230); // Fundo semi-transparente
  fill(0);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("Festejando Conexão do Campo e da Cidade", width / 2, height / 2 - 180);
  textSize(24);
  text("Um Endless Runner", width / 2, height / 2 - 140);

  textSize(20);
  text("Objetivo: Evite obstáculos e colete power-ups para alcançar a linha de chegada (10.000 pontos).", width / 2, height / 2 - 60);
  text("Controles:", width / 2, height / 2 - 20);
  text("  • Setas esquerda/direita ou botões na tela: movimentação.", width / 2, height / 2 + 10);
  text("  • Seta para cima ou botão na tela: pular.", width / 2, height / 2 + 40);
  text("Atalhos:", width / 2, height / 2 + 80);
  text("  • Tecla M: Começar/Reiniciar o jogo.", width / 2, height / 2 + 110);
  text("  • Tecla E ou botão 'Pause/Resume': Pausar/Resumir o jogo.", width / 2, height / 2 + 140);

  textSize(28);
  text("Pressione M para Iniciar!", width / 2, height - 100);
}

function displayGameOver() {
  fill(255, 0, 0, 180); // Vermelho semi-transparente
  rect(0, 0, width, height);
  fill(255);
  textSize(60);
  textAlign(CENTER, CENTER);
  text("GAME OVER!", width / 2, height / 2 - 50);
  textSize(30);
  text("Sua pontuação: " + score, width / 2, height / 2 + 20);
  textSize(24);
  text("Pressione M para Reiniciar", width / 2, height / 2 + 80);
}

function displayFinish() {
  fill(0, 255, 0, 180); // Verde semi-transparente
  rect(0, 0, width, height);
  fill(255);
  textSize(60);
  textAlign(CENTER, CENTER);
  text("PARABÉNS!", width / 2, height / 2 - 50);
  textSize(30);
  text("Você completou o desafio com " + score + " pontos!", width / 2, height / 2 + 20);
  textSize(24);
  text("Pressione M para Jogar Novamente", width / 2, height / 2 + 80);
}


// ===============================================
// CONTROLES E INPUTS
// ===============================================

function drawPauseButton() {
  let buttonWidth = 120;
  let buttonHeight = 40;
  let x = width - buttonWidth - 20;
  let y = 20;
  fill(0, 0, 0, 150);
  rect(x, y, buttonWidth, buttonHeight, 10);
  fill(255);
  textSize(20);
  textAlign(CENTER, CENTER);
  if (gameState === "playing") {
    text("Pause", x + buttonWidth / 2, y + buttonHeight / 2);
  } else if (gameState === "paused") {
    text("Resume", x + buttonWidth / 2, y + buttonHeight / 2);
  }
  pauseButtonRect = {
    x: x,
    y: y,
    w: buttonWidth,
    h: buttonHeight
  };
}

function mousePressed() {
  // Se o jogo está em playing ou paused, verifica se o clique foi no botão de pause.
  if ((gameState === "playing" || gameState === "paused") && pauseButtonRect) {
    if (
      mouseX >= pauseButtonRect.x &&
      mouseX <= pauseButtonRect.x + pauseButtonRect.w &&
      mouseY >= pauseButtonRect.y &&
      mouseY <= pauseButtonRect.y + pauseButtonRect.h
    ) {
      if (gameState === "playing") {
        gameState = "paused";
      } else {
        gameState = "playing";
      }
    }
  }
}

function keyPressed() {
  // Inicia ou reinicia o jogo com tecla M (menu, gameOver ou finished)
  if ((gameState === "menu" || gameState === "gameOver" || gameState === "finished") &&
    (key === "m" || key === "M")) {
    resetGame();
  }
  // Alterna entre pause e resume com a tecla E durante o jogo
  if ((gameState === "playing" || gameState === "paused") && (key === "e" || key === "E")) {
    if (gameState === "playing") {
      gameState = "paused";
    } else {
      gameState = "playing";
    }
  }
}

function resetGame() {
  gameState = "playing";
  initializeGameElements(); // Re-inicializa todos os elementos do jogo
}

function drawControls() {
  let buttonSize = 60;
  let margin = 20;
  let baseX = margin;
  let baseY = height - buttonSize * 3 - margin;

  controlButtons.up = {
    x: baseX + buttonSize,
    y: baseY,
    w: buttonSize,
    h: buttonSize
  };
  controlButtons.left = {
    x: baseX,
    y: baseY + buttonSize,
    w: buttonSize,
    h: buttonSize
  };
  controlButtons.down = {
    x: baseX + buttonSize,
    y: baseY + 2 * buttonSize,
    w: buttonSize,
    h: buttonSize
  };
  controlButtons.right = {
    x: baseX + buttonSize * 2,
    y: baseY + buttonSize,
    w: buttonSize,
    h: buttonSize
  };

  noStroke();
  fill(0, 0, 0, 100);
  for (let d in controlButtons) {
    let btn = controlButtons[d];
    rect(btn.x, btn.y, btn.w, btn.h, 10);

    fill(255);
    textAlign(CENTER, CENTER);
    textSize(24);
    if (d === "up") text("↑", btn.x + btn.w / 2, btn.y + btn.h / 2);
    if (d === "down") text("↓", btn.x + btn.w / 2, btn.y + btn.h / 2);
    if (d === "left") text("←", btn.x + btn.w / 2, btn.y + btn.h / 2);
    if (d === "right") text("→", btn.x + btn.w / 2, btn.y + btn.h / 2);
  }
}

function getControlInput() {
  let ctrl = {
    up: false,
    down: false,
    left: false,
    right: false
  };
  if (touches.length > 0) {
    for (let t of touches) {
      for (let d in controlButtons) {
        let btn = controlButtons[d];
        if (
          t.x >= btn.x &&
          t.x <= btn.x + btn.w &&
          t.y >= btn.y &&
          t.y <= btn.y + btn.h
        ) {
          ctrl[d] = true;
        }
      }
    }
  } else if (mouseIsPressed) { // Adicionado mouseIsPressed para simular toque em desktop
    for (let d in controlButtons) {
      let btn = controlButtons[d];
      if (
        mouseX >= btn.x &&
        mouseX >= btn.x &&
        mouseX <= btn.x + btn.w &&
        mouseY >= btn.y &&
        mouseY <= btn.y + btn.h
      ) {
        ctrl[d] = true;
      }
    }
  }
  return ctrl;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  groundY = height * 0.75;
  // Recalcular posições dos elementos estáticos do fundo se necessário
  initializeGameElements(); // Recria elementos para se ajustarem ao novo tamanho
}